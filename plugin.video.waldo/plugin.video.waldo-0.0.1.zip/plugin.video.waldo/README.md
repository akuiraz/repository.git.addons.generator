plugin.video.waldo
==================

xbmc plugin allow browsing lists of content from multiple addons and finding that content from multiple sources