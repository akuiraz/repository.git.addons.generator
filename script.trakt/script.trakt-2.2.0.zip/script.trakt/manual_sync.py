# -*- coding: utf-8 -*-

import utilities as utils

if __name__ == '__main__':

	# set property for service to initiate a manual sync
	utils.setProperty('traktManualSync', 'True')
