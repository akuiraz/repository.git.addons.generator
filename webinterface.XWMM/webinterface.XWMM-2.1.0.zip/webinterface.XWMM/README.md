XWMM - XBMC Web Media Manager
====

### Frodo Version:
Zernable Contributed a version of XWMM for Frodo. Most of the functionality of the Eden version is working including editing of movie, TV and music metadata.

- - -
Features not yet working - Todo list:

* Changing artwork
* Managing movie sets, genres and actors (although these can be changed on a per movie/TV/music basis)
* The "Files" tab

- - -
Install Via Zip mode in XBMC.

### Download:
XWMM Frodo.zip [click here to download](https://github.com/slash2009/XWMM/archive/frodo.zip "Title")
- - -
