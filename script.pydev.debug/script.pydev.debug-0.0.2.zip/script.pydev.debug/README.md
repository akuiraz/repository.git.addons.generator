script.pydev.debug
==================

XBMC support for Pydev debugging.