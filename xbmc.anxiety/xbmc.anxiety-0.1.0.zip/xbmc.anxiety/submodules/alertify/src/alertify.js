define(["proto"], function (AlertifyProto) {
    "use strict";

    var Alertify = function () {};
    Alertify.prototype = AlertifyProto;
    Alertify = new Alertify();

    return Alertify;
});
